namespace Publisher.Application.Common.Models.Instagram;

public record InstagramAuthUrl(string AuthUrl);
