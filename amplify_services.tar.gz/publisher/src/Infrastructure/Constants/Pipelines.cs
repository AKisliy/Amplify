namespace Publisher.Infrastructure.Constants;

public static class Pipelines
{
    public static readonly string InstagramContainerStatusCheckPipelineName = "instagram-container-status-checking";
}

