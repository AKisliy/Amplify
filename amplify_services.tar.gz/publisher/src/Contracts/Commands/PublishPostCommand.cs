namespace Contracts.Commands;

public record PublishPostCommand(Guid PublicationRecordId);

