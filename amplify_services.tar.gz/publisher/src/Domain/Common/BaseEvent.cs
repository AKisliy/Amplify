﻿using MediatR;

namespace Publisher.Domain.Common;

public abstract class BaseEvent : INotification
{
}
