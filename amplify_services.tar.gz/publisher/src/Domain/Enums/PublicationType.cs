namespace Publisher.Domain.Enums;

public enum PublicationType
{
    Manual = 1,
    AutoList = 2
}
