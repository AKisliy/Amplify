namespace Publisher.Domain.Enums;

public enum SocialProvider
{
    Instagram = 1,
    TikTok = 2,
    Youtube = 4
}