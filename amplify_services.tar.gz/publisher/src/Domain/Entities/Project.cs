
namespace Publisher.Domain.Entities;

public class Project : BaseEntity
{
}
