namespace Publisher.Domain.Entities;

public partial class Cover : BaseEntity
{
    public Guid MediaId { get; set; }
}
