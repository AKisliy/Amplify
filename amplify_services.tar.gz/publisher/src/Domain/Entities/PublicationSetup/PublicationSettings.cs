namespace Publisher.Domain.Entities.PublicationSetup;

public class PublicationSettings
{
    public InstagramSettings? Instagram { get; set; }
}
