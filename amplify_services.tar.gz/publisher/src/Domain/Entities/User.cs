namespace Publisher.Domain.Entities;

public class User : BaseEntity;
