﻿using MediatR;

namespace UserService.Domain.Common;

public abstract class BaseEvent : INotification
{
}
