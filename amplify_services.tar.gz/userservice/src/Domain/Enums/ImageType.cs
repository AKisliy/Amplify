namespace UserService.Domain.Enums;

public enum ImageType
{
    Other = 0,
    FullBody = 1,
    Portrait = 2
}
