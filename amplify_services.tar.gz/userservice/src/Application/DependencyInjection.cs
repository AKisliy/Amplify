﻿using System.Reflection;
using UserService.Application.Common.Behaviours;
using Microsoft.Extensions.Hosting;
using UserService.Application.Common.Options;

namespace Microsoft.Extensions.DependencyInjection;

public static class DependencyInjection
{
    public static void AddApplicationServices(this IHostApplicationBuilder builder)
    {
        builder.Services.AddAutoMapper(Assembly.GetExecutingAssembly());

        builder.Services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

        builder.Services.AddMediatR(cfg =>
        {
            cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly());
            cfg.AddOpenRequestPreProcessor(typeof(LoggingBehaviour<>));
            cfg.AddOpenBehavior(typeof(UnhandledExceptionBehaviour<,>));
            cfg.AddOpenBehavior(typeof(AuthorizationBehaviour<,>));
            cfg.AddOpenBehavior(typeof(ValidationBehaviour<,>));
            cfg.AddOpenBehavior(typeof(PerformanceBehaviour<,>));
        });

        builder.Services.AddApplicationOptions();
    }

    private static void AddApplicationOptions(this IServiceCollection services)
    {
        services.AddOptions<FrontendOptions>().BindConfiguration(FrontendOptions.SectionName);
        services.AddOptions<ExternalUrlsOptions>().BindConfiguration(ExternalUrlsOptions.SectionName);
    }
}
