namespace UserService.Application.Auth.Login;

public record LoginResponse(string AccessToken, string RefreshToken);
