global using Ardalis.GuardClauses;
global using UserService.Web.Infrastructure;
global using MediatR;
