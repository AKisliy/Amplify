namespace UserService.Web.Endpoints;

public class AmbassadorImages : EndpointGroupBase
{
    public override string? GroupName => "ambassador-images";

    public override void Map(RouteGroupBuilder groupBuilder)
    {
    }

}
