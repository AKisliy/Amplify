﻿using MediatR;

namespace MediaIngest.Domain.Common;

public abstract class BaseEvent : INotification
{
}
