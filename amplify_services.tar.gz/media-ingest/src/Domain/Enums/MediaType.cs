namespace MediaIngest.Domain.Enums;

public enum MediaType
{
    Video,
    Audio,
    VideoAudio
}
