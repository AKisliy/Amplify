namespace MediaIngest.Domain.Enums;

public enum FileType
{
    LuxuryFragment,
    LuxuryReference,
    Broll,
    Voiceover,
    Hook
}
