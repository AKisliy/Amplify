﻿global using Ardalis.GuardClauses;
global using FluentValidation;