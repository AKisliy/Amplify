global using Ardalis.GuardClauses;
global using MediaIngest.Web.Infrastructure;
global using MediatR;
